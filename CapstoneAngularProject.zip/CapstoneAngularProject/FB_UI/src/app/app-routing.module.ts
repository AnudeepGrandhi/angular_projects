import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//Add required imports


const routes: Routes = [
  /* Add routes here */
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
